#include <behaviortree_cpp_v3/bt_factory.h>
#include <behaviortree_cpp_v3/loggers/bt_cout_logger.h>
#include <rclcpp/rclcpp.hpp>

#include "behaviour_tree/bt_nodes.hpp"

int main(int argc, char **argv)
{
  rclcpp::init(argc, argv);
  auto node = rclcpp::Node::make_shared("bt_waypoint_node");

  BT::BehaviorTreeFactory factory;

  factory.registerNodeType<GoToWaypoint>("GoToWaypoint");

  auto blackboard = BT::Blackboard::create();
  blackboard->set("node", node);

  static const char* xml_text = R"(
  <root main_tree_to_execute="MainTree">
    <BehaviorTree ID="MainTree">
      <Sequence>
        <GoToWaypoint x="-3.0" y="-3.0"/>
        <GoToWaypoint x="0.0" y="0.0"/>
        <GoToWaypoint x="3.5" y="3.5"/>
      </Sequence>
    </BehaviorTree>
  </root>
)";

  auto tree = factory.createTreeFromText(xml_text, blackboard);
  BT::StdCoutLogger logger(tree);

  rclcpp::Rate rate(10);

  while (rclcpp::ok())
  {
    tree.tickRoot();
    rclcpp::spin_some(node);
    rate.sleep();
  }

  rclcpp::shutdown();
  return 0;
}

