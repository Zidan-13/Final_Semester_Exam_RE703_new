#include "behaviour_tree/bt_nodes.hpp"

#include <rclcpp/rclcpp.hpp>
#include <geometry_msgs/msg/twist.hpp>
#include <nav_msgs/msg/odometry.hpp>

#include <tf2/LinearMath/Quaternion.h>
#include <tf2/utils.h>

#include <cmath>

using namespace std::chrono_literals;

// ================= CONSTRUCTOR =================
GoToWaypoint::GoToWaypoint(
  const std::string& name,
  const BT::NodeConfiguration& config)
: BT::StatefulActionNode(name, config)
{
  // Ambil node ROS dari blackboard
  node_ = config.blackboard->get<rclcpp::Node::SharedPtr>("node");

  // Publisher ke cmd_vel (twist_mux -> diff_cont)
  cmd_pub_ = node_->create_publisher<geometry_msgs::msg::Twist>(
    "/cmd_vel", 10);

  // Subscribe odom dari diff drive controller
  odom_sub_ = node_->create_subscription<nav_msgs::msg::Odometry>(
    "/diff_cont/odom", 10,
    std::bind(&GoToWaypoint::odomCallback, this, std::placeholders::_1)
  );

  RCLCPP_INFO(node_->get_logger(), "GoToWaypoint node initialized");
}

// ================= PORTS =================
BT::PortsList GoToWaypoint::providedPorts()
{
  return {
    BT::InputPort<double>("x"),
    BT::InputPort<double>("y")
  };
}

// ================= START =================
BT::NodeStatus GoToWaypoint::onStart()
{
  getInput("x", goal_x_);
  getInput("y", goal_y_);

  RCLCPP_INFO(
    node_->get_logger(),
    "GoToWaypoint START → Goal (%.2f , %.2f)",
    goal_x_, goal_y_
  );

  return BT::NodeStatus::RUNNING;
}

// ================= RUNNING =================
BT::NodeStatus GoToWaypoint::onRunning()
{
  double dx = goal_x_ - x_;
  double dy = goal_y_ - y_;
  double distance = std::sqrt(dx * dx + dy * dy);

  geometry_msgs::msg::Twist cmd;

  // === Target reached ===
  if (distance < 0.1)
  {
    cmd_pub_->publish(geometry_msgs::msg::Twist());
    RCLCPP_INFO(node_->get_logger(), "Waypoint reached");
    return BT::NodeStatus::SUCCESS;
  }

  // === Heading control ===
  double target_yaw = std::atan2(dy, dx);
  double yaw_error = normalizeAngle(target_yaw - yaw_);

  cmd.linear.x  = 0.2;
  cmd.angular.z = yaw_error;

  cmd_pub_->publish(cmd);
  return BT::NodeStatus::RUNNING;
}

// ================= HALTED =================
void GoToWaypoint::onHalted()
{
  cmd_pub_->publish(geometry_msgs::msg::Twist());
  RCLCPP_WARN(node_->get_logger(), "GoToWaypoint halted");
}

// ================= ODOM CALLBACK =================
void GoToWaypoint::odomCallback(
  const nav_msgs::msg::Odometry::SharedPtr msg)
{
  x_ = msg->pose.pose.position.x;
  y_ = msg->pose.pose.position.y;

  tf2::Quaternion q(
    msg->pose.pose.orientation.x,
    msg->pose.pose.orientation.y,
    msg->pose.pose.orientation.z,
    msg->pose.pose.orientation.w
  );

  yaw_ = tf2::getYaw(q);
}

// ================= UTIL =================
double GoToWaypoint::normalizeAngle(double angle)
{
  while (angle > M_PI)  angle -= 2.0 * M_PI;
  while (angle < -M_PI) angle += 2.0 * M_PI;
  return angle;
}

