#include "behaviour_tree/bt_nodes.hpp"

#include <tf2/LinearMath/Quaternion.h>
#include <tf2/utils.h>
#include <cmath>

using namespace std::chrono_literals;

GoToWaypoint::GoToWaypoint(const std::string& name,
                           const BT::NodeConfiguration& config)
: BT::StatefulActionNode(name, config)
{
  node_ = config.blackboard->get<rclcpp::Node::SharedPtr>("node");

  cmd_pub_ = node_->create_publisher<geometry_msgs::msg::Twist>("/cmd_vel", 10);
  odom_sub_ = node_->create_subscription<nav_msgs::msg::Odometry>(
    "/diff_cont/odom", 10,
    std::bind(&GoToWaypoint::odomCallback, this, std::placeholders::_1)
  );
}

BT::PortsList GoToWaypoint::providedPorts()
{
  return {
    BT::InputPort<double>("x"),
    BT::InputPort<double>("y")
  };
}

BT::NodeStatus GoToWaypoint::onStart()
{
  getInput("x", goal_x_);
  getInput("y", goal_y_);
  RCLCPP_INFO(node_->get_logger(), "GoToWaypoint START: (%.2f, %.2f)", goal_x_, goal_y_);
  return BT::NodeStatus::RUNNING;
}

BT::NodeStatus GoToWaypoint::onRunning()
{
  double dx = goal_x_ - x_;
  double dy = goal_y_ - y_;
  double distance = std::sqrt(dx*dx + dy*dy);

  geometry_msgs::msg::Twist cmd;

  if (distance < 0.1)
  {
    cmd_pub_->publish(geometry_msgs::msg::Twist());
    RCLCPP_INFO(node_->get_logger(), "Waypoint reached");
    return BT::NodeStatus::SUCCESS;
  }

  double target_yaw = std::atan2(dy, dx);
  double error_yaw = normalizeAngle(target_yaw - yaw_);

  cmd.linear.x = 0.2;
  cmd.angular.z = error_yaw;

  cmd_pub_->publish(cmd);
  return BT::NodeStatus::RUNNING;
}

void GoToWaypoint::onHalted()
{
  cmd_pub_->publish(geometry_msgs::msg::Twist());
}

void GoToWaypoint::odomCallback(const nav_msgs::msg::Odometry::SharedPtr msg)
{
  x_ = msg->pose.pose.position.x;
  y_ = msg->pose.pose.position.y;

  tf2::Quaternion q(
    msg->pose.pose.orientation.x,
    msg->pose.pose.orientation.y,
    msg->pose.pose.orientation.z,
    msg->pose.pose.orientation.w
  );

  yaw_ = tf2::getYaw(q);
}

double GoToWaypoint::normalizeAngle(double angle)
{
  while (angle > M_PI) angle -= 2*M_PI;
  while (angle < -M_PI) angle += 2*M_PI;
  return angle;
}

